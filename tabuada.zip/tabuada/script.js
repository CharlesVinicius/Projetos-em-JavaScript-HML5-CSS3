function visualizar(){

    let tab = document.getElementById('tab')
    let selec = document.getElementById('seltab')

    if(tab.value.length == 0){
        alert('Digite um numero!')
    }

    else{

        let t = Number(tab.value)

        selec.innerHTML =''

        for(c = 1; c <= 10; c++){

            let item = document.createElement('option')
            item.text = `${t} x ${c} = ${t * c}`
            item.value=`tab${c}`
            selec.appendChild(item)



        }



    }




}
