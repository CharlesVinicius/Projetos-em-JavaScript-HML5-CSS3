let numero1 = document.getElementById('numb')
let numero2 = document.getElementById('numb2')
let res = document.getElementById('res')




function Somar(){

    if(numero1.value.length == 0 && numero2.value.length == 0 || numero1.value == 0 && numero2.value==0){
        res.innerHTML=`Impossivel prosseguir com dois valores 0 e entrada fazia de dados`
    }else{
        
    

let n1 = Number(numero1.value)
let n2 = Number(numero2.value)



    let valor = n1 + n2
    res.innerHTML=`Soma: ${valor}<br>`
    }
}

function Subtrair(){

    if(numero1.value.length == 0 && numero2.value.length == 0 || numero1.value == 0 && numero2.value==0){
        res.innerHTML=`Impossivel prosseguir com dois valores 0 ou entrada fazia de dados`
    }else{
        
    let n1 = Number(numero1.value)
    let n2 = Number(numero2.value)
    let valor = n1 - n2
    res.innerHTML=`Subtracao: ${valor}<br>`
    }
}

function divisao(){
    if(numero1.value.length == 0 && numero2.value.length == 0 || numero1.value == 0 && numero2.value==0){
        res.innerHTML=`Impossivel prosseguir com dois valores 0 ou entrada fazia de dados`
    }else{
        
    let n1 = Number(numero1.value)
    let n2 = Number(numero2.value)
    let valor = n1 / n2
    res.innerHTML=`Divisão: ${valor}`
    }
}
function mult(){
    if(numero1.value.length == 0 && numero2.value.length == 0 || numero1.value == 0 && numero2.value == 0){
        res.inputMode=`Impossivel prosseguir com dois valores 0 ou entrada fazia de dados`
    }else{
        let n1 = Number(numero1.value)
        let n2 = Number(numero2.value)
        let valor = n1 * n2
        res.innerHTML=`Muntiplicação: ${valor}`
    }
}
function limpar(){
    res.innerHTML=''
}

